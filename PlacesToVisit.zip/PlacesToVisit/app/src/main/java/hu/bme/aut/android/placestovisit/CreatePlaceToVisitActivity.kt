package hu.bme.aut.android.placestovisit

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import hu.bme.aut.android.placestovisit.data.Place
import kotlinx.android.synthetic.main.activity_create_place_to_visit.*
import java.util.Date

class CreatePlaceToVisitActivity : Activity() {

    companion object {
        const val KEY_EDIT_PLACE = "KEY_EDIT_PLACE"
        const val KEY_EDIT_POSITION = "KEY_EDIT_POSITION"
        const val KEY_PLACE = "KEY_PLACE"
    }

    private var inEditMode = false
    private var editPosition = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_place_to_visit)

        val adapter = ArrayAdapter.createFromResource(this, R.array.placetypes_array, android.R.layout.simple_spinner_item)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerPlaceType.adapter = adapter

        val intent = intent
        if (intent != null && intent.hasExtra(KEY_EDIT_PLACE)) {
            inEditMode = true

            val place = intent.getSerializableExtra(KEY_EDIT_PLACE) as Place

            spinnerPlaceType.setSelection(place.placeType.value)
            etPlaceName.setText(place.placeName)
            etPlaceDesc.setText(place.description)

            editPosition = intent.getIntExtra(KEY_EDIT_POSITION, -1)
        }

        btnSave.setOnClickListener {
            if (inEditMode) {
                updatePlace()
            } else {
                savePlace()
            }
        }
    }

    private fun updatePlace() {
        val intentResult = Intent()
        intentResult.putExtra(KEY_PLACE, Place(
                placeType = Place.PlaceType.fromInt(spinnerPlaceType.selectedItemPosition),
                placeName = etPlaceName.text.toString(),
                description = etPlaceDesc.text.toString(),
                creationDate = Date(System.currentTimeMillis())
        ))
        intentResult.putExtra(KEY_EDIT_POSITION, editPosition)
        setResult(RESULT_OK, intentResult)
        finish()
    }

    private fun savePlace() {
        val intentResult = Intent()
        intentResult.putExtra(KEY_PLACE, Place(
                placeType = Place.PlaceType.fromInt(spinnerPlaceType.selectedItemPosition),
                placeName = etPlaceName.text.toString(),
                description = etPlaceDesc.text.toString(),
                creationDate = Date(System.currentTimeMillis())
        ))
        setResult(RESULT_OK, intentResult)
        finish()
    }

}
