package hu.bme.aut.android.placestovisit.data


import android.arch.persistence.room.Dao
import android.arch.persistence.room.Delete
import android.arch.persistence.room.Insert
import android.arch.persistence.room.Query
import android.arch.persistence.room.Update

@Dao
interface PlaceDao {

    @Insert
    fun insertAll(vararg places: Place)

    @Query("SELECT * FROM Place")
    fun getAll(): List<Place>

    @Update
    fun updatePlace(place: Place): Int

    @Delete
    fun delete(place: Place)

}
