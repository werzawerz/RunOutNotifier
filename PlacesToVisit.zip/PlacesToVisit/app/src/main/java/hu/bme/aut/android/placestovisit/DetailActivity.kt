package hu.bme.aut.android.placestovisit

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import hu.bme.aut.android.placestovisit.data.Place
import kotlinx.android.synthetic.main.activity_create_place_to_visit.*
import kotlinx.android.synthetic.main.activity_detail.*
import java.text.SimpleDateFormat


class DetailActivity : AppCompatActivity() {

    companion object {
        const val KEY_EDIT_PLACE = "KEY_EDIT_PLACE"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        if (intent != null && intent.hasExtra(DetailActivity.KEY_EDIT_PLACE)) {

            val place = intent.getSerializableExtra(DetailActivity.KEY_EDIT_PLACE) as Place

            TvLocationSetter.setText(place.placeName);
            TvDescriptionSetter.setText(place.description)
            val format = SimpleDateFormat("dd/MM/yyy")
            val s : String = format.format(place.creationDate)
            TvDateSetter.setText(s)
        }


    }



}