package com.example.runoutnotifier.model

class MyItem(
   // val id : Long? = null,
    val name : String,
    val purchaseDate : String,
    val dueDate : String? = null,
    val quantity : Double,
    val type : Type
) {
    enum class Type {
        Gramm, Kilogramm, Liter, Piece, Packet, Box, Other
    }

}