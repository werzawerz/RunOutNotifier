package com.example.runoutnotifier

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.RecyclerView
import android.support.design.widget.Snackbar
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import com.example.runoutnotifier.adapter.SimpleItemRecyclerViewAdapter

import com.example.runoutnotifier.model.MyItem
import kotlinx.android.synthetic.main.activity_item_list.*
import kotlinx.android.synthetic.main.item_list.*

/**
 * An activity representing a list of Pings. This activity
 * has different presentations for handset and tablet-size devices. On
 * handsets, the activity presents a list of items, which when touched,
 * lead to a [ItemDetailActivity] representing
 * item details. On tablets, the activity presents the list of items and
 * item details side-by-side using two vertical panes.
 */
class ItemListActivity : AppCompatActivity(), SimpleItemRecyclerViewAdapter.MyItemClickListener, NewItemFragment.NewItemListener {

    private lateinit var recycler : SimpleItemRecyclerViewAdapter

    override fun onClick(item: MyItem) {
        if(twoPane) {
            val fragment = MyItemDetailFragment()
            fragment.setItem(item)
            supportFragmentManager
                .beginTransaction()
                .replace(R.id.item_detail_container, fragment)
                .commit()
        }
        else {
            ItemDetailActivity.selectedItem = item
            val intent = Intent(this, ItemDetailActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onLongClick(pos: Int, view : View) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_options, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        if (item?.itemId == R.id.addNewItem) {
            val todoCreateFragment = NewItemFragment()
            todoCreateFragment.show(supportFragmentManager, "TAG")
        }

        return super.onOptionsItemSelected(item)
    }

    /**
     * Whether or not the activity is in two-pane mode, i.e. running on a tablet
     * device.
     */
    private var twoPane: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_item_list)

        setSupportActionBar(toolbar)
        toolbar.title = title

        fab.setOnClickListener { view ->
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show()
        }

        if (item_detail_container != null) {
            // The detail container view will be present only in the
            // large-screen layouts (res/values-w900dp).
            // If this view is present, then the
            // activity should be in two-pane mode.
            twoPane = true
        }

        setupRecyclerView()
    }

    private fun setupRecyclerView() {
        val DemoData =  mutableListOf(
            MyItem("alma", "2019.01.01", "2019.03.03", 6.0, MyItem.Type.Piece),
            MyItem("krumpli", "2019.03.01", "2019.03.03", 12.0, MyItem.Type.Kilogramm),
            MyItem("cigi", "2019.03.02", "2019.03.03", 1.0, MyItem.Type.Packet)
        )

        recycler = SimpleItemRecyclerViewAdapter()
        recycler.itemClickListener = this
        recycler.addAll(DemoData)
        item_list.adapter = recycler


    }

    override fun onItemCreated(item: MyItem) {
       // SimpleItemRecyclerViewAdapter.addItem(item)
    }

}
